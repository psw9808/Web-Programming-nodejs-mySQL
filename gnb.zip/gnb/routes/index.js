var express = require('express');
var fs = require('fs');
var router = express.Router();

var posts = require('../posts.json');

const uuidv1 = require('uuid/v1');

router.get('/', function (req, res) {
  res.render('gnb', { posts: posts })
})

router.get('/:abc', function(req, res) {
  var targetIndex = posts.findIndex(function(element) {
    return element.id == req.params.abc
  })
  var targetPost = posts[targetIndex]
  res.render('detail', {post: targetPost})
})

router.post('/', function (req, res) {
  var newObj = {
    id: uuidv1(),
    title: req.body.title,
    body: req.body.gnb_body
  }
  posts.push(newObj)

  fs.writeFile('posts.json', JSON.stringify(posts), function () {
    res.redirect('back')
  })
})

module.exports = router;
