var express = require('express');
var fs = require('fs');
var router = express.Router();

var posts = require('../posts.json');

const uuidv1 = require('uuid/v1');

router.get('/', function (req, res) {
  res.render('gnb', { posts: posts })
})

router.get('/:abc', function(req, res) {
  var targetIndex = posts.findIndex(function(element) {
    return element.id == req.params.abc
  })
  var targetPost = posts[targetIndex]
  res.render('detail', {post: targetPost})
})

router.post('/', function (req, res) {
  var newObj = {
    id: uuidv1(),
    title: req.body.title,
    body: req.body.gnb_body
  }
  posts.push(newObj)

  fs.writeFile('posts.json', JSON.stringify(posts), function () {
    res.redirect('back')
  })
})

router.get("/update_post/:post_id", function(req, res) {
  var targetIndex = posts.findIndex(function(element) {
    return element.id == req.params.post_id
  })
  var targetPost = posts[targetIndex]
  res.render('update', {post: targetPost})
})

router.post("/update_post/:post_id", function(req, res) {
  var index = posts.findIndex(function(element) {
    return element.id == req.params.post_id
  })
  
  posts[index].title=req.body.title
  posts[index].body=req.body.body

  fs.writeFile('posts.json', JSON.stringify(posts), function () {
    res.redirect('/')
  })
})


router.post("/delete_post/:post_id", function(req, res){
  var index = posts.findIndex(function(element) {
    return element.id == req.params.post_id
  })
  
  posts.splice(index, 1)

  fs.writeFile('posts.json', JSON.stringify(posts), function () {
    res.redirect('/')
  })

})

const Sequelize = require('sequelize');

const sequelize = new Sequelize('gnb', 'root', '0000', {
  host: 'localhost',
  dialect: 'mysql'
});

const Post = sequelize.define('post', {
  // attributes
  id: {
    primaryKey: true,
    type: Sequelize.STRING,
    allowNull: false
  },
  title: {
    type: Sequelize.STRING
  },
  body: {
    type: Sequelize.STRING
  }
});  

Post.sync()

module.exports = router;
